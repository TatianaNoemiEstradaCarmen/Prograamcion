/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.DetalleVentas;
import model.Ventas;

/**
 *
 * @author USUARIO
 */
public class VentasDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r=0;
    
    public String SerieVenta(){
        String serie = "";
        String sql = "select max(numeroventa) from ventas";
        try{
            con = cn.ObtenerConexion();
            ps = con.prepareCall(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                serie = rs.getString(1);
            }
        }catch (Exception e){
            
        }
        return serie;
    }
    
    public String IdVenta(){
        String idv = "";
        String sql="select max(id_venta) from ventas";
        try{
            con = cn.ObtenerConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                idv = rs.getString(1);
            }
            
        }catch(Exception e){
            
        }
        return idv;
    }
    
    public int GuardarVentas(Ventas v){
        Ventas ventas = new Ventas();
        String sql="insert into ventas(id_dueño,numeroventa,fecha,monto)values(?,?,?,?)";
        try{
            con = cn.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, v.getIdDueño());
            ps.setString(2, v.getSerie());
            ps.setString(3, v.getFecha());
            ps.setDouble(4, v.getMonto());
            r=ps.executeUpdate();
        }catch (Exception e){
            
        }
        return r;
    }
    
    public int GuardarDetalleVentas(DetalleVentas dv){
       String sql="insert into detalle_ventas(venta,medicamento,cantidad,precio)values(?,?,?,?)";
       try{
           con = cn.ObtenerConexion();
           ps = con.prepareStatement(sql);
           ps.setInt(1,dv.getIdVentas());
           ps.setString(2,dv.getIdMedicamento());
           ps.setInt(3,dv.getCantidad());
           ps.setDouble(4,dv.getPrecio());
           ps.executeUpdate();
       } catch(Exception e){
           
       }
        return r;
    }
}
