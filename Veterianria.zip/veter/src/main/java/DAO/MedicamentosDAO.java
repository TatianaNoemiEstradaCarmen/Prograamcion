/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Medicamentos;

/**
 *
 * @author USUARIO
 */
public class MedicamentosDAO {
    Connection con;
    Conexion cn= new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    Medicamentos md = new Medicamentos();
    
    public Medicamentos listarID(String nombre){
        /*Instanciar la entidad Dueño*/
        Medicamentos d = new Medicamentos();
        String sql="select * from medicamentos where nombre =?";
        try{
            con = cn.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            while (rs.next()){
                d.setCodigo(rs.getString(1));
                d.setNombre(rs.getString(2));
                d.setPrecio(rs.getDouble(3));
                d.setStock(rs.getInt(4));
            }
        }catch(Exception e){
            
        }
        return d;
    }
}
