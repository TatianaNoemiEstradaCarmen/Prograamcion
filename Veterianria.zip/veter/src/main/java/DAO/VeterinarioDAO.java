/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Veterinarios;

/**
 *
 * @author USUARIO
 */
public class VeterinarioDAO {
    Connection con;
    Conexion cn= new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    Veterinarios vt = new Veterinarios();
    
    public Veterinarios listarID(String nombre){
        /*Instanciar la entidad Dueño*/
        Veterinarios d = new Veterinarios();
        String sql="select * from veterinario where nombre_veteri =?";
        try{
            con = cn.ObtenerConexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            while (rs.next()){
                d.setCodigo(rs.getString(1));
                d.setNombre(rs.getString(2));
                d.setEspecialidad(rs.getString(3));
                d.setLicencia(rs.getString(4));
                d.setCelular(rs.getString(5));
                d.setCorreo(rs.getString(6));
            }
        }catch(Exception e){
            
        }
        return d;
    }
}
