/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;
import model.Dueños;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public interface IDueños {
    List<Dueños> getAllDueños();
    void addDueños(Dueños Du);
    void removeDueños(Dueños Du);
    void updateDueños(Dueños Du);
    List<Dueños> searchById(String codigo);
}
