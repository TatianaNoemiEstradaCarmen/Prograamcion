/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import Util.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Medicamentos;

/**
 *
 * @author USUARIO
 */
public class MedicamentosRepository implements IMedicamentos {

    @Override
    public List<Medicamentos> getAllMedicamentos() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Medicamentos> lstMedicamentos = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListarMedi()}");
            ResultSet rsD = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsD.next())
            {
                Medicamentos objMed = new Medicamentos();/*CREA EL OBJETO*/
                objMed.setCodigo(rsD.getString("codigo"));
                objMed.setNombre(rsD.getString("nombre"));
                objMed.setPrecio(rsD.getDouble("precio"));
                objMed.setStock(rsD.getInt("stock"));
                
                lstMedicamentos.add(objMed);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsD.close();
            return lstMedicamentos;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public void addMedicamentos(Medicamentos Med) {
        try
      {
          PreparedStatement sMed = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarMedi(?,?,?,?)}");
          sMed.setString(1, Med.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sMed.setString(2, Med.getNombre());
          sMed.setDouble(3, Med.getPrecio());
          sMed.setInt(4, Med.getStock());
          sMed.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }
    }

    @Override
    public void removeMedicamentos(Medicamentos Met) {
       try
        {
            PreparedStatement sMed = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarMedi(?)}");
            sMed.setString(1, Met.getCodigo());/*pasando los datos al parámetro del SP*/
            sMed.executeUpdate();/*Actualizar la BD*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }

    @Override
    public void updateMedicamentos(Medicamentos Med) {
        try
      {
          PreparedStatement sMed = Conexion.ObtenerConexion().prepareStatement("{CALL USPUpdateMed(?,?,?,?)}");
          sMed.setString(1, Med.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sMed.setString(2, Med.getNombre());
          sMed.setDouble(3, Med.getPrecio());
          sMed.setInt(4, Med.getStock());
          sMed.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }  
    }

    


    

      
    
}
