/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import Util.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Dueños;
import model.IdMem;
import model.Membresia;
import model.Tipo;

/**
 *
 * @author USUARIO
 */
public class MembresiaRepository implements IMembresia{

    @Override
    public List<IdMem> getAllCodigo() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<IdMem> lstIdMem = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sM = Conexion.ObtenerConexion().prepareCall("{CALL USPListarCod()}");
            ResultSet rsM = sM.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsM.next())
            {
                IdMem objId = new IdMem();/*CREA EL OBJETO*/
                objId.setId(rsM.getString("id"));
                
                
                
                lstIdMem.add(objId);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsM.close();
            return lstIdMem;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Tipo> getAllTipo() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Tipo> lstTipo = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListarNom()}");
            ResultSet rsM = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsM.next())
            {
                Tipo obj = new Tipo();/*CREA EL OBJETO*/
                obj.setNombre(rsM.getString("nombre"));
                lstTipo.add(obj);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsM.close();
            return lstTipo;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Dueños> getAllDueños() {
       try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Dueños> lstDueños = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sV = Conexion.ObtenerConexion().prepareCall("{CALL USPListarDuen()}");
            ResultSet rsV = sV.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsV.next())
            {
                Dueños obj = new Dueños();/*CREA EL OBJETO*/
                obj.setNombre(rsV.getString("nombre_dueño"));
                lstDueños.add(obj);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsV.close();
            return lstDueños;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public void addMembresia(Membresia Mem) {
        try
      {
          PreparedStatement sCit = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarMembresia(?,?,?)}");
          sCit.setString(1, Mem.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sCit.setString(2, Mem.getNombre());
          sCit.setString(3, Mem.getDueño());
          sCit.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }
    }

    @Override
    public void removeMembresia(Membresia Mem) {
        try
        {
            PreparedStatement sCit = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarMembresia(?)}");
            sCit.setString(1, Mem.getCodigo());/*pasando los datos al parámetro del SP*/
            sCit.executeUpdate();/*Actualizar la BD*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }

    @Override
    public void updateMembresia(Membresia Mem) {
        try
      {
          PreparedStatement sCit = Conexion.ObtenerConexion().prepareStatement("{CALL USPUpdateMembresia(?,?,?)}");
          sCit.setString(1, Mem.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sCit.setString(2, Mem.getNombre());
          sCit.setString(3, Mem.getDueño());
          sCit.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }  
    }

    @Override
    public List<Membresia> getAllMembresia() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Membresia> lstMembresia = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListarMembresia()}");
            ResultSet rsD = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsD.next())
            {
                Membresia objC = new Membresia();/*CREA EL OBJETO*/
                objC.setCodigo(rsD.getString("id_mem"));
                objC.setNombre(rsD.getString("nombre"));
                objC.setDueño(rsD.getString("dueño"));            
                lstMembresia.add(objC);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsD.close();
            return lstMembresia;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Membresia> searchById(String codigo) {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Membresia> lstMembresia = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sDu = Conexion.ObtenerConexion().prepareCall("{CALL USPBuscarMembresia(?)}");
            sDu.setString(1, codigo);/*pasando los datos al parámetro del SP*/
            ResultSet rsCit = sDu.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsCit.next())
            {
                Membresia objC = new Membresia();/*CREA EL OBJETO*/
                objC.setCodigo(rsCit.getString("id_nom"));
                objC.setNombre(rsCit.getString("nombre"));
                objC.setDueño(rsCit.getString("dueño"));              
                lstMembresia.add(objC);/*ASIGNAR EL OBJ A LA LISTA*/
                break;/*ROMPE WHILE*/
            }
            Conexion.ObtenerConexion().close();
            rsCit.close();
            return lstMembresia;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }
}
  
    

