/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import Util.Conexion;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Citas;
import model.Codigo;
import model.Fecha;
import model.Hora;
import model.Mascotas;
import model.Veterinarios;

/**
 *
 * @author USUARIO
 */
public class CitaRepository implements ICita {

    @Override
    public List<Mascotas> getAllNombres() {
       try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Mascotas> lstMascotas = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListMascota()}");
            ResultSet rsM = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsM.next())
            {
                Mascotas obj = new Mascotas();/*CREA EL OBJETO*/
                obj.setNombre(rsM.getString("nombre"));
                lstMascotas.add(obj);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsM.close();
            return lstMascotas;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Veterinarios> getAllVeterinarios() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Veterinarios> lstVet = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sV = Conexion.ObtenerConexion().prepareCall("{CALL USPListarVete()}");
            ResultSet rsV = sV.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsV.next())
            {
                Veterinarios obj = new Veterinarios();/*CREA EL OBJETO*/
                obj.setNombre(rsV.getString("nombre_veteri"));
                lstVet.add(obj);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsV.close();
            return lstVet;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Fecha> getAllFecha() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Fecha> lstFecha = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sF = Conexion.ObtenerConexion().prepareCall("{CALL USPListarFecha()}");
            ResultSet rsF = sF.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsF.next())
            {
                Fecha obj = new Fecha();/*CREA EL OBJETO*/
                obj.setFecha(rsF.getDate("fecha"));
                lstFecha.add(obj);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsF.close();
            return lstFecha;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Hora> getAllHora() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Hora> lstHora = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sF = Conexion.ObtenerConexion().prepareCall("{CALL USPListarHora()}");
            ResultSet rsH = sF.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsH.next())
            {
                Hora obj = new Hora();/*CREA EL OBJETO*/
                obj.setHora(rsH.getString("hora"));
                lstHora.add(obj);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsH.close();
            return lstHora;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public List<Citas> getAllCitas() {
        
       try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Citas> lstCitas = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sD = Conexion.ObtenerConexion().prepareCall("{CALL USPListarCitas()}");
            ResultSet rsD = sD.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsD.next())
            {
                Citas objC = new Citas();/*CREA EL OBJETO*/
                objC.setCodigo(rsD.getString("Id_cita"));
                objC.setNombre(rsD.getString("nombre"));
                objC.setVeterinario(rsD.getString("veterinario"));
                objC.setFecha(rsD.getString("fecha"));
                objC.setHora(rsD.getString("hora"));               
                lstCitas.add(objC);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsD.close();
            return lstCitas;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
        
    }

    @Override
    public void addCitas(Citas cit) {
        try
      {
          PreparedStatement sCit = Conexion.ObtenerConexion().prepareStatement("{CALL USPInsertarC(?,?,?,?,?)}");
          sCit.setString(1, cit.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sCit.setString(2, cit.getNombre());
          sCit.setString(3, cit.getVeterinario());
          sCit.setString(4, cit.getFecha());
          sCit.setString(5, cit.getHora());
          sCit.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }
    }

    @Override
    public List<Codigo> getAllCodigo() {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Codigo> lstCodigo = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sM = Conexion.ObtenerConexion().prepareCall("{CALL USPListarCodigo()}");
            ResultSet rsM = sM.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsM.next())
            {
                Codigo objCit = new Codigo();/*CREA EL OBJETO*/
                objCit.setCodigo(rsM.getString("codigo"));
                
                
                
                lstCodigo.add(objCit);/*ASIGNAR EL OBJ A LA LISTA*/
            }
            Conexion.ObtenerConexion().close();
            rsM.close();
            return lstCodigo;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

    @Override
    public void removeCitas(Citas cit) {
         try
        {
            PreparedStatement sCit = Conexion.ObtenerConexion().prepareStatement("{CALL USPEliminarC(?)}");
            sCit.setString(1, cit.getCodigo());/*pasando los datos al parámetro del SP*/
            sCit.executeUpdate();/*Actualizar la BD*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
    }

    @Override
    public void updateCitas(Citas cit) {
        try
      {
          PreparedStatement sCit = Conexion.ObtenerConexion().prepareStatement("{CALL USPUpdateC(?,?,?,?,?)}");
          sCit.setString(1, cit.getCodigo());/*PASA DATOS A LOS PARÁMETROS*/
          sCit.setString(2, cit.getNombre());
          sCit.setString(3, cit.getVeterinario());
          sCit.setString(4, cit.getFecha());
          sCit.setString(5, cit.getHora());
          sCit.executeUpdate();/*ES PARA EL CRUD-ACTUALIZAR*/
      }
      catch(Exception e)
      {
          e.getMessage();
      }  
    }

    @Override
    public List<Citas> searchById(String codigo) {
        try{
            /*CREACIÓN DE ARREGLO DINÁMICO*/
            List<Citas> lstCitas = new ArrayList<>();
            /*LLAMAR AL STORE PROCEDURE*/
            CallableStatement sDu = Conexion.ObtenerConexion().prepareCall("{CALL USPBuscarC(?)}");
            sDu.setString(1, codigo);/*pasando los datos al parámetro del SP*/
            ResultSet rsCit = sDu.executeQuery();
            /*RECORRE RS/ ASIGNA DATOS AL ARREGLO DE OBJ*/
            while(rsCit.next())
            {
                Citas objC = new Citas();/*CREA EL OBJETO*/
                objC.setCodigo(rsCit.getString("Id_cita"));
                objC.setNombre(rsCit.getString("nombre"));
                objC.setVeterinario(rsCit.getString("veterinario"));
                objC.setFecha(rsCit.getString("Fecha"));
                objC.setHora(rsCit.getString("Hora"));
              
                lstCitas.add(objC);/*ASIGNAR EL OBJ A LA LISTA*/
                break;/*ROMPE WHILE*/
            }
            Conexion.ObtenerConexion().close();
            rsCit.close();
            return lstCitas;/*RETORNAR EL ARREGLO DINAMICO DE LOS DATOS DE LA TABLA*/
        }
        catch(Exception e)
        {
            e.getMessage();
        }
        return null;
    }

   
    
}
