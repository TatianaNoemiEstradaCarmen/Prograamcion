/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Citas;
import model.Codigo;

import model.Fecha;
import model.Hora;
import model.Mascotas;
import model.Veterinarios;

/**
 *
 * @author USUARIO
 */
public interface ICita {
    List<Mascotas>getAllNombres();
    List<Veterinarios>getAllVeterinarios();
    List<Fecha>getAllFecha();
    List<Hora>getAllHora();
    List<Citas> getAllCitas();
    List<Codigo>getAllCodigo();
    void addCitas(Citas cit);
    void removeCitas(Citas cit);
    void updateCitas(Citas cit);
    List<Citas> searchById(String codigo); 
   
}
