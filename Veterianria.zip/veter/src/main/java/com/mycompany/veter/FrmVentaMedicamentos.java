/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.veter;

import com.itextpdf.text.pdf.parser.Matrix;
import controller.DetalleController;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.DetalleVentas;
import DAO.DueñoDAO;
import model.Dueños;
import DAO.MedicamentoDAO;
import model.Medicamentos;
import model.Ventas;
import model.VentasDAO;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.rendering.PDFRenderer;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;


/**
 *
 * @author USUARIO
 */
public class FrmVentaMedicamentos extends javax.swing.JFrame {
   VentasDAO vdao = new VentasDAO();
   DueñoDAO ddao = new DueñoDAO();
   MedicamentoDAO mdao = new MedicamentoDAO();
   Medicamentos m = new Medicamentos();
   Ventas  v = new Ventas ();
   DetalleVentas dv = new DetalleVentas();
   
   
   Dueños dueños = new Dueños();
   
   DefaultTableModel modelo = new DefaultTableModel();
   int cant;
   double pre;
   double tpagar;
    
    public FrmVentaMedicamentos() {
        initComponents();
        setLocationRelativeTo(null);
        generarSerie();
        fecha();
        transparenciaButton();
               
    }
    
    
    void fecha(){
        Calendar fecha = new GregorianCalendar();
        int año = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH);
        int dia = fecha.get(Calendar.DATE);
        txtFecha.setText("" + dia + "/" + (mes + 1) + "/" + año);
    }
    
    void generarSerie(){
        String serie = vdao.SerieVenta();
        if(serie == null){
            txtSerie.setText("0000001");
        }else{
            int increment = Integer.parseInt(serie);
            increment = increment + 1;
            txtSerie.setText("000000"+increment);
        }
    }
    
    public void transparenciaButton(){
        btntotal.setOpaque(false);
        btntotal.setContentAreaFilled(false);
        btntotal.setBorderPainted(false);
        
        regresar.setOpaque(false);
        regresar.setContentAreaFilled(false);
        regresar.setBorderPainted(false);
        
        btnGuardar.setOpaque(false);
        btnGuardar.setContentAreaFilled(false);
        btnGuardar.setBorderPainted(false);
        
        ticket1.setOpaque(false);
        ticket1.setContentAreaFilled(false);
        ticket1.setBorderPainted(false);
        
        btnnuevos.setOpaque(false);
        btnnuevos.setContentAreaFilled(false);
        btnnuevos.setBorderPainted(false);
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        link = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        label_na8 = new javax.swing.JLabel();
        ticket = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        link1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jventa = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtCodCli = new javax.swing.JTextField();
        label_na9 = new javax.swing.JLabel();
        txtstock = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        txtDatoCli = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtCodMedi = new javax.swing.JTextField();
        btnBuscarMed = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtprecio = new javax.swing.JTextField();
        btnBuscarMed1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jSpinnerP = new javax.swing.JSpinner();
        jLabel13 = new javax.swing.JLabel();
        txtcodmed = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        regresar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtSerie = new javax.swing.JTextField();
        Icon = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        btntotal = new javax.swing.JButton();
        ticket1 = new javax.swing.JButton();
        btnnuevos = new javax.swing.JButton();

        link.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link.setForeground(new java.awt.Color(153, 0, 153));
        link.setText("VENTA DE MEDICAMENTOS");
        link.setToolTipText("");

        jLabel5.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 255));
        jLabel5.setText("ID");

        label_na8.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na8.setForeground(new java.awt.Color(102, 102, 255));
        label_na8.setText("Nombre");

        ticket.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        ticket.setForeground(new java.awt.Color(0, 102, 102));
        ticket.setText("TICKET");
        ticket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                ticketMouseReleased(evt);
            }
        });
        ticket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ticketActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        link1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link1.setForeground(new java.awt.Color(153, 0, 153));
        link1.setText("VENTA DE MEDICAMENTOS");
        link1.setToolTipText("");

        jventa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nro.", "Código", "Medicamento", "Cantidad", "Precio Unitario", "Total"
            }
        ));
        jScrollPane1.setViewportView(jventa);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ventas", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 18), new java.awt.Color(0, 153, 51))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 102));
        jLabel6.setText("COD.CLIENTE:");

        txtCodCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodCliActionPerformed(evt);
            }
        });

        label_na9.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        label_na9.setForeground(new java.awt.Color(204, 0, 102));
        label_na9.setText("MEDICAMENTO:");

        txtstock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtstockActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        btnBuscar.setForeground(new java.awt.Color(0, 102, 102));
        btnBuscar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\buscar.png")); // NOI18N
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(204, 0, 102));
        jLabel11.setText("CLIENTE:");

        txtCodMedi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodMediActionPerformed(evt);
            }
        });

        btnBuscarMed.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        btnBuscarMed.setForeground(new java.awt.Color(0, 102, 102));
        btnBuscarMed.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\med2.png")); // NOI18N
        btnBuscarMed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarMedActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 0, 102));
        jLabel12.setText("PRECIO     :");

        jLabel7.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 0, 102));
        jLabel7.setText("STOCK  :");

        txtprecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprecioActionPerformed(evt);
            }
        });

        btnBuscarMed1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        btnBuscarMed1.setForeground(new java.awt.Color(0, 102, 102));
        btnBuscarMed1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\agregar.png")); // NOI18N
        btnBuscarMed1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarMed1ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 102));
        jLabel8.setText("CANTIDAD   :");

        jLabel13.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(204, 0, 102));
        jLabel13.setText("CODIGO :");

        jLabel9.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 102));
        jLabel9.setText("FECHA  :");

        txtFecha.setText("jTextField2");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(label_na9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCodMedi, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                            .addComponent(txtCodCli)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtprecio, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                            .addComponent(jSpinnerP))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnBuscarMed1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel7))
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtstock)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 140, Short.MAX_VALUE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(btnBuscarMed, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel13))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel11)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDatoCli)
                            .addComponent(txtcodmed, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE))))
                .addGap(22, 22, 22))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnBuscar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtCodCli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtDatoCli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel11)))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(label_na9)
                                .addComponent(txtCodMedi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnBuscarMed, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel13)
                                .addComponent(txtcodmed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtstock)
                                    .addComponent(jLabel7)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel12)
                                    .addComponent(txtprecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnBuscarMed1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jSpinnerP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );

        btnGuardar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        btnGuardar.setForeground(new java.awt.Color(0, 102, 102));
        btnGuardar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\venta2.png")); // NOI18N
        btnGuardar.setText("Venta");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        regresar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(0, 102, 102));
        regresar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\regresar2.png")); // NOI18N
        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Cascadia Mono", 2, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 51, 51));
        jLabel10.setText("NRO. SERIE:");

        txtSerie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSerieActionPerformed(evt);
            }
        });

        Icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\iguana2.png")); // NOI18N

        jLabel14.setFont(new java.awt.Font("Cascadia Mono", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(204, 0, 102));
        jLabel14.setText("TOTAL:");

        txtTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Cascadia Mono", 2, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(51, 204, 0));
        jLabel15.setText("VETERINARIA LA IGUANA");

        btntotal.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        btntotal.setForeground(new java.awt.Color(0, 102, 102));
        btntotal.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\total2.png")); // NOI18N
        btntotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntotalActionPerformed(evt);
            }
        });

        ticket1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        ticket1.setForeground(new java.awt.Color(0, 102, 102));
        ticket1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\tic2.png")); // NOI18N
        ticket1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ticket1ActionPerformed(evt);
            }
        });

        btnnuevos.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\nuevo3.png")); // NOI18N
        btnnuevos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnuevosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Icon)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(138, 138, 138)
                                .addComponent(link1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(191, 191, 191)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel15)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtSerie, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(regresar)
                            .addGap(18, 18, 18)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(ticket1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnnuevos, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btntotal, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel14)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)))
                .addGap(0, 15, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(link1)
                        .addGap(5, 5, 5)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(txtSerie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btntotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ticket1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(regresar)
                        .addComponent(btnGuardar)
                        .addComponent(jLabel14)
                        .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnnuevos, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCodCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodCliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodCliActionPerformed

    private void txtstockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtstockActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstockActionPerformed

    private void txtprecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtprecioActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // Verificar si alguno de los campos está vacío
        int rsta = 1;
        if (txtCodCli.getText().isEmpty() || txtDatoCli.getText().isEmpty() || 
            txtCodMedi.getText().isEmpty() || txtcodmed.getText().isEmpty() || 
            txtprecio.getText().isEmpty() || txtstock.getText().isEmpty() ||
            jSpinnerP.getValue() == null) {
            // Mostrar mensaje de error
            JOptionPane.showMessageDialog(this, "Complete todos los campos.", "Campos vacíos", JOptionPane.ERROR_MESSAGE);
        } else {
            guardarVentas();
            guardarDetalle();
            actualizarStock();
            JOptionPane.showConfirmDialog(this, "Realizar venta?");
        }
    }
    
    void actualizarStock(){
       for (int i=0; i <modelo.getRowCount(); i++){
           Medicamentos pr = new Medicamentos();
           String idp = jventa.getValueAt(i,1).toString();
           cant = Integer.parseInt(jventa.getValueAt(i,3).toString()); 
           pr = mdao.listarID2(idp);
           int sa = pr.getStock()-cant;/*sa almacena stock de producto, sin ser actualizado*/
           mdao.actualizarStock(sa, idp);
       } 
    }
    
    void guardarVentas(){
        String idd = dueños.getCodigo();
        String serie = txtSerie.getText();
        String fecha = txtFecha.getText();
        double monto = tpagar;
        /*Instacia de Ventas*/
        v.setIdDueño(idd);
        v.setSerie(serie);
        v.setFecha(fecha);
        v.setMonto(monto);
        vdao.GuardarVentas(v);
    }
    void guardarDetalle(){
        String idv = vdao.IdVenta();/*IdVentas calcual el máximo de IdVentas */
        int idve = Integer.parseInt(idv);/*Covertimos a entero la variable IdVentas*/
        for(int i = 0; i<jventa.getRowCount(); i++){
            /*Variable de tipo entero para el IdMedicamento*/
            String idm = (jventa.getValueAt(i,1).toString());
            int cant = Integer.parseInt(jventa.getValueAt(i,3).toString());
            double pre = Double.parseDouble(jventa.getValueAt(i,4).toString());
            dv.setIdVentas(idve);
            dv.setIdMedicamento(idm);
            dv.setCantidad(cant);
            dv.setPrecio(pre);
            /*Agregado los datos dentro del objeto, ejecutamos el método de la clase VentasDAO */
            vdao.GuardarDetalleVentas(dv);/*Este método se ejecuta dentro del for, el límite es la cantidad de medicamentos agregados*/
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        FrmMedicamentos pc = new FrmMedicamentos();
        pc.setVisible(true);
    }//GEN-LAST:event_regresarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        // TODO add your handling code here:
        buscarDueño();
    }
        void buscarDueño(){
            int rsta;
            String cod=  txtCodCli.getText();
            if (txtCodCli.getText().equals("")){
                JOptionPane.showMessageDialog(this,"Ingresar Codigo del Dueño");
            }else{
                dueños = ddao.listarID(cod);
                if (dueños.getDni()!=null){
                    txtDatoCli.setText(dueños.getNombre());
                    txtCodMedi.requestFocus();
                }else{
                    rsta = JOptionPane.showConfirmDialog(this,"Dueño no registrado,¿Desea registrar?");
                    if(rsta == 0){
                        FrmDueños df = new FrmDueños();
                        df.setVisible(true);
                    }
                }
            }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnBuscarMedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarMedActionPerformed
        // TODO add your handling code here:
         buscarMedicamento();
    }
        void buscarMedicamento(){
            /*convertir*/
           String nombre = txtCodMedi.getText();
           if(txtCodMedi.getText().equals("")){
               JOptionPane.showMessageDialog(this,"Ingresar el código del medicamento");
           }else{
               Medicamentos m = mdao.listarID(nombre);
               if (m.getNombre()!=null){
                   txtcodmed.setText(""+m.getCodigo());
                   txtprecio.setText(""+m.getPrecio());
                   txtstock.setText(""+m.getStock());
               }else{
                   JOptionPane.showMessageDialog(this,"Medicamento no registrado");
                   txtCodMedi.requestFocus();
               }
           }
    }//GEN-LAST:event_btnBuscarMedActionPerformed

    private void btnBuscarMed1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarMed1ActionPerformed
        // TODO add your handling code here:
       agregarMedicamento();
    }
        void agregarMedicamento(){
            double monto;
            int item = 0;
            modelo =(DefaultTableModel)jventa.getModel();
            /*Item para agregar a la tabla*/
            item = item + 1;
            String idM = txtcodmed.getText();
            String nom = txtCodMedi.getText();
            pre = Double.parseDouble(txtprecio.getText());
            cant = Integer.parseInt(jSpinnerP.getValue().toString());
            int stock = Integer.parseInt(txtstock.getText());
            monto= cant * pre;
            
            /*Declarar variable de tipo Array List*/
            ArrayList lista = new ArrayList();/*Instanciar*/
            if(stock>0){
                    lista.add(item);
                    lista.add(idM);
                    lista.add(nom);
                    lista.add(cant);
                    lista.add(pre);
                    lista.add(monto);
                    /*Agregar dentro de un objeto*/
                    Object[] ob=new Object[6];
                    ob[0] = lista.get(0);
                    ob[1] = lista.get(1);
                    ob[2] = lista.get(2);
                    ob[3] = lista.get(3);
                    ob[4] = lista.get(4);
                    ob[5] = lista.get(5);
                    /*Agregar el objeto dentro del modelo*/
                    modelo.addRow(ob);
                    jventa.setModel(modelo);
                    /*Método para calcular el total*/
                    calcularTotal();
            }else{
                JOptionPane.showMessageDialog(this, "Stock insuficiente");
            }   
        }
        void calcularTotal(){
            /*Inicializar la variable total a pagar*/
            tpagar=0;
            for(int i=0; i< jventa.getRowCount(); i++){
                cant = Integer.parseInt(jventa.getValueAt(i,3).toString());
                pre = Double.parseDouble(jventa.getValueAt(i,4).toString());
                tpagar = tpagar+(cant * pre);
        }
        txtTotal.setText(""+tpagar);
    }//GEN-LAST:event_btnBuscarMed1ActionPerformed

    private void txtCodMediActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodMediActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodMediActionPerformed

    private void txtTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalActionPerformed

    private void btntotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btntotalActionPerformed

    private void ticketMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ticketMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_ticketMouseReleased

    private void ticketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ticketActionPerformed
        
    }//GEN-LAST:event_ticketActionPerformed

    private void ticket1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ticket1ActionPerformed
        // TODO add your handling code here:
     try {
        // Crear un documento PDF
        PDDocument document = new PDDocument();

        // Crear una página en el documento
        PDPage page = new PDPage();
        document.addPage(page);

        // Crear un objeto PDFRenderer para renderizar el contenido del JFrame
        PDFRenderer renderer = new PDFRenderer(document);

        // Capturar el contenido del JFrame en una imagen
        BufferedImage image = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = image.createGraphics();
        paint(graphics);
        graphics.dispose();

        // Convertir la imagen a un objeto PDImageXObject
        PDImageXObject pdImage = LosslessFactory.createFromImage(document, image);

        // Obtener el contenido de la página y dibujar la imagen en ella
        PDPageContentStream contentStream = new PDPageContentStream(document, page);
        contentStream.drawImage(pdImage, 0, 0, page.getMediaBox().getWidth(), page.getMediaBox().getHeight());
        contentStream.close();

        // Guardar el documento como archivo PDF
        String nombreArchivo = txtDatoCli.getText().toString().replaceAll("[^a-zA-Z0-9.-]", "") + ".pdf";
        document.save("C:\\Users\\USUARIO\\OneDrive\\Documentos\\Tickets\\" + nombreArchivo);
        document.close();

        System.out.println("Documento PDF creado correctamente.");
    } catch (IOException ex) {
        ex.printStackTrace();
    }
        
    }//GEN-LAST:event_ticket1ActionPerformed

    private void txtSerieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSerieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSerieActionPerformed

    private void btnnuevosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnuevosActionPerformed
        // TODO add your handling code here:
        txtCodCli.setText(""); // Limpia el contenido del textField
        txtDatoCli.setText(""); 
        txtCodMedi.setText("");
        txtcodmed.setText("");
        txtprecio.setText("");
        txtstock.setText("");
        SpinnerModel model = new SpinnerNumberModel(); 
        jSpinnerP.setModel(model);
        DefaultTableModel tableModel = (DefaultTableModel) jventa.getModel();
        tableModel.setRowCount(0);      
    }//GEN-LAST:event_btnnuevosActionPerformed
    
   

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmVentaMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmVentaMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmVentaMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmVentaMedicamentos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmVentaMedicamentos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Icon;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnBuscarMed;
    private javax.swing.JButton btnBuscarMed1;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnnuevos;
    private javax.swing.JButton btntotal;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinnerP;
    private javax.swing.JTable jventa;
    private javax.swing.JLabel label_na8;
    private javax.swing.JLabel label_na9;
    private javax.swing.JLabel link;
    private javax.swing.JLabel link1;
    private javax.swing.JButton regresar;
    private javax.swing.JButton ticket;
    private javax.swing.JButton ticket1;
    private javax.swing.JTextField txtCodCli;
    private javax.swing.JTextField txtCodMedi;
    private javax.swing.JTextField txtDatoCli;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtSerie;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtcodmed;
    private javax.swing.JTextField txtprecio;
    private javax.swing.JTextField txtstock;
    // End of variables declaration//GEN-END:variables

    
    
}
