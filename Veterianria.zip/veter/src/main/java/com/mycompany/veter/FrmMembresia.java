/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.veter;
import controller.MembresiaController;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Citas;
import model.Dueños;
import model.IdMem;
import model.Membresia;
import model.Tipo;
/**
 *
 * @author USUARIO
 */
public class FrmMembresia extends javax.swing.JFrame {
    
private DefaultTableModel dtmMembresia = new DefaultTableModel();
private MembresiaController MController = new MembresiaController();

    /**
     * Creates new form NewJFrame
     */
    public FrmMembresia() {
        initComponents();
        cargarCombo();
        llenaTabla();
        llenaLista();
        transparenciaButton();
        setLocationRelativeTo(null);/**Ventana salga centrada**/
    }
    public void cargarCombo()
    {
        List<Tipo> lst = MController.getAllTipoController();
        for(Tipo item:lst)
        {
            this.jboxti.addItem(item.getNombre() + " ");
        }
        List<Dueños> lstD = MController.getAllDueñosController();
        for(Dueños item:lstD)
        {
            this.jboxn.addItem(item.getNombre()+ " ");
        }
    }
    
    public void llenaTabla()
    {
        dtmMembresia.addColumn("Id");
        dtmMembresia.addColumn("Tipo de Membresia");
        dtmMembresia.addColumn("Nombre");
        this.Tmem.setModel(dtmMembresia);
    }
    
    public void llenaLista()
    {
        List<Membresia> lst = MController.getlstMembreciaController();
        dtmMembresia.setRowCount(0);
        for(int i=0; i<lst.size();i++)
        {
            Object[] vec=new Object[3];
            vec[0] = lst.get(i).getCodigo();
            vec[1] = lst.get(i).getNombre();
            vec[2] = lst.get(i).getDueño();
            dtmMembresia.addRow(vec);                 
        }
        this.Tmem.setModel(dtmMembresia);    
    }
    
     public void transparenciaButton(){
        jButton2.setOpaque(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setBorderPainted(false);
        
        subir_dueño1.setOpaque(false);
        subir_dueño1.setContentAreaFilled(false);
        subir_dueño1.setBorderPainted(false);
        
        editar1.setOpaque(false);
        editar1.setContentAreaFilled(false);
        editar1.setBorderPainted(false);
        
        eliminar1.setOpaque(false);
        eliminar1.setContentAreaFilled(false);
        eliminar1.setBorderPainted(false);
        
        regresar.setOpaque(false);
        regresar.setContentAreaFilled(false);
        regresar.setBorderPainted(false);
        
        buscar.setOpaque(false);
        buscar.setContentAreaFilled(false);
        buscar.setBorderPainted(false);
    }

        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        subir_dueño = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        link1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        Idd = new javax.swing.JTextField();
        label_na7 = new javax.swing.JLabel();
        labels1 = new javax.swing.JLabel();
        jboxti = new javax.swing.JComboBox<>();
        jboxn = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        subir_dueño1 = new javax.swing.JButton();
        editar1 = new javax.swing.JButton();
        eliminar1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tmem = new javax.swing.JTable();
        regresar = new javax.swing.JButton();
        Icon = new javax.swing.JLabel();
        buscar = new javax.swing.JButton();

        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 102, 102));
        jButton1.setText("NUEVO");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        subir_dueño.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        subir_dueño.setForeground(new java.awt.Color(0, 102, 102));
        subir_dueño.setText("GUARDAR");
        subir_dueño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subir_dueñoActionPerformed(evt);
            }
        });

        editar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        editar.setForeground(new java.awt.Color(0, 102, 102));
        editar.setText("EDITAR");

        eliminar.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        eliminar.setForeground(new java.awt.Color(0, 102, 102));
        eliminar.setText("ELIMINAR");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        link1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link1.setForeground(new java.awt.Color(153, 0, 153));
        link1.setText("MEMBRESIA");
        link1.setToolTipText("");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registro", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Cascadia Mono", 0, 14), new java.awt.Color(102, 0, 51))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 0, 102));
        jLabel2.setText("ID");

        label_na7.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        label_na7.setForeground(new java.awt.Color(204, 0, 102));
        label_na7.setText("Nombre");

        labels1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        labels1.setForeground(new java.awt.Color(204, 0, 102));
        labels1.setText("Tipo de membresia");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(labels1)
                    .addComponent(label_na7))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Idd, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(169, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jboxti, 0, 238, Short.MAX_VALUE)
                            .addComponent(jboxn, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Idd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labels1)
                    .addComponent(jboxti, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label_na7)
                    .addComponent(jboxn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 102, 102));
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\nuevo3.png")); // NOI18N
        jButton2.setText("Nuevo");
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        subir_dueño1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        subir_dueño1.setForeground(new java.awt.Color(0, 102, 102));
        subir_dueño1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\guardar2.png")); // NOI18N
        subir_dueño1.setText("Guardar");
        subir_dueño1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        subir_dueño1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        subir_dueño1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subir_dueño1ActionPerformed(evt);
            }
        });

        editar1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        editar1.setForeground(new java.awt.Color(0, 102, 102));
        editar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\editar2.png")); // NOI18N
        editar1.setText("Editar");
        editar1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editar1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editar1ActionPerformed(evt);
            }
        });

        eliminar1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        eliminar1.setForeground(new java.awt.Color(0, 102, 102));
        eliminar1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\eliminar2.png")); // NOI18N
        eliminar1.setText("Eliminar");
        eliminar1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        eliminar1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        eliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminar1ActionPerformed(evt);
            }
        });

        Tmem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Tmem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TmemMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Tmem);

        regresar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(0, 102, 102));
        regresar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\regresar3.png")); // NOI18N
        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        Icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\iguana2.png")); // NOI18N

        buscar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        buscar.setForeground(new java.awt.Color(0, 102, 102));
        buscar.setText("Buscar");
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(regresar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 484, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton2)
                                .addGap(62, 62, 62)
                                .addComponent(subir_dueño1)
                                .addGap(49, 49, 49)
                                .addComponent(editar1)
                                .addGap(57, 57, 57)
                                .addComponent(eliminar1)))))
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(Icon)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(link1)
                .addGap(188, 188, 188))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(link1))
                    .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(subir_dueño1)
                    .addComponent(editar1)
                    .addComponent(eliminar1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regresar)
                    .addComponent(buscar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void subir_dueñoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subir_dueñoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_subir_dueñoActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Idd.setText(""); // Limpia el contenido del textField
        jboxti.setSelectedItem("");
        jboxn.setSelectedItem("");

    }//GEN-LAST:event_jButton2ActionPerformed

    private void subir_dueño1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subir_dueño1ActionPerformed
        
        Membresia objMem = new Membresia();
        objMem.setCodigo(Idd.getText());
        objMem.setNombre(jboxti.getSelectedItem().toString());
        objMem.setDueño(jboxn.getSelectedItem().toString());

        // Verificar si todos los campos están llenos
        if (objMem.getCodigo().isEmpty() || objMem.getNombre().isEmpty() || objMem.getDueño().isEmpty()) {
            // Mostrar mensaje de error indicando los campos faltantes
            String mensaje = "Falta completar los siguientes campos:\n";
            if (objMem.getCodigo().isEmpty()) {
                mensaje += "* Código\n";
            }
            if (objMem.getNombre().isEmpty()) {
                mensaje += "* Nombre\n";
            }
            if (objMem.getDueño().isEmpty()) {
                mensaje += "* Dueño\n";
            }
            JOptionPane.showMessageDialog(this, mensaje, "No se puede completar la acción", JOptionPane.ERROR_MESSAGE);
        } else {
            MController.addMembresiaController(objMem);
            JOptionPane.showMessageDialog(this, "Membresia registrada satisfactoriamente!!");
            llenaLista();
        }
    }//GEN-LAST:event_subir_dueño1ActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        FrmPrincipal pc = new FrmPrincipal();
        pc.setVisible(true);
    }//GEN-LAST:event_regresarActionPerformed

    private void TmemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TmemMouseClicked
        // TODO add your handling code here:
        this.Idd.setText(this.dtmMembresia.getValueAt(this.Tmem.getSelectedRow(),0).toString());
        this.jboxti.setSelectedItem(this.dtmMembresia.getValueAt(this.Tmem.getSelectedRow(),1).toString());
        this.jboxn.setSelectedItem(this.dtmMembresia.getValueAt(this.Tmem.getSelectedRow(),3).toString());
    }//GEN-LAST:event_TmemMouseClicked

    private void editar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editar1ActionPerformed
        // TODO add your handling code here:
        Membresia objMas = new Membresia();/*CREA EL OBJETO*/
            objMas.setCodigo(this.Idd.getText());
            objMas.setNombre((String) this.jboxti.getSelectedItem());
            objMas.setDueño((String) this.jboxn.getSelectedItem());
            MController.updateMembresiaController(objMas);
            JOptionPane.showMessageDialog(this, "Membresia actualizado satisfactoriamente!!");
            llenaLista();
    }//GEN-LAST:event_editar1ActionPerformed

    private void eliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminar1ActionPerformed
        // TODO add your handling code here:
        int option = JOptionPane.showConfirmDialog(this, "¿Deseas realizar esta acción?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
        Membresia objMas = new Membresia();/*CREA EL OBJETO*/
        objMas.setCodigo(this.Idd.getText());/*PASAR PARAMETRO DEL CODIGO*/
        MController.removeMembresiaController(objMas);/*LLAMR AL METODO*/
        
        llenaLista();/*LISTA ACTUALIZADA*/
           JOptionPane.showMessageDialog(this, "Membresia eliminada satisfactoriamente!!'");
            } else if (option == JOptionPane.NO_OPTION) {
           JOptionPane.showMessageDialog(this, "Acción Cancelada");
            }
    }//GEN-LAST:event_eliminar1ActionPerformed

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
        // TODO add your handling code here:
        /**if (DController.searchById(getCodigo()) == null) {
            JOptionPane.showMessageDialog(this, "Dueño no Encontrado");
            return;

        }
        Dueños objDu = DController.searchById(getCodigo());
        JOptionPane.showMessageDialog(this, "Código: " + objDu.getCodigo() + "\nNombre: "
            + objDu.getNombre() + "\nDni: S/." + objDu.getDni()
            + "\nTelefono: " + objDu.getTelefono()
            + "\nDireccion: " + objDu.getDireccion()
            + "\nCorreo: " + objDu.getCorreo());**/

    }//GEN-LAST:event_buscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmMembresia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmMembresia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmMembresia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmMembresia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmMembresia().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Icon;
    private javax.swing.JTextField Idd;
    private javax.swing.JTable Tmem;
    private javax.swing.JButton buscar;
    private javax.swing.JButton editar;
    private javax.swing.JButton editar1;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton eliminar1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jboxn;
    private javax.swing.JComboBox<String> jboxti;
    private javax.swing.JLabel label_na7;
    private javax.swing.JLabel labels1;
    private javax.swing.JLabel link1;
    private javax.swing.JButton regresar;
    private javax.swing.JButton subir_dueño;
    private javax.swing.JButton subir_dueño1;
    // End of variables declaration//GEN-END:variables


    
}
