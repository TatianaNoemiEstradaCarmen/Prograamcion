package com.mycompany.veter;

import DAO.MascotasDAO;
import Util.Conexion;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import controller.MascotasController;
import controller.DueñosController;
import java.awt.HeadlessException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Dueños;
import model.Mascotas;


/**
 *
 * @author Usuario
 */
public final class FrmMascotas extends javax.swing.JFrame {
private DefaultTableModel dtmMascotas = new DefaultTableModel();
private MascotasController MController = new MascotasController();
MascotasDAO mdao = new MascotasDAO();
Conexion con = new Conexion();
Connection cn = con.ObtenerConexion();

Mascotas mascotas = new Mascotas();

    /**
     * Creates new form mascotas_r
     */
    public FrmMascotas() {
        initComponents();
        cargarCombo();
        llenaTabla();
        llenaLista();
        transparenciaButton();
        setLocationRelativeTo(null);/**Ventana salga centrada**/
       
    }
    public void cargarCombo()
    {
        List<Dueños> lst = MController.getAllNombresController();
        for(Dueños item:lst)
        {
            this.Combodue.addItem(item.getNombre() + " ");
        }
        
        
    }
    public void llenaTabla()
    {
        dtmMascotas.addColumn("CODIGO");
        dtmMascotas.addColumn("NOMBRE");
        dtmMascotas.addColumn("RAZA");
        dtmMascotas.addColumn("EDAD");
        dtmMascotas.addColumn("PESO");
        dtmMascotas.addColumn("TAMAÑO");
        dtmMascotas.addColumn("DUEÑO");
        this.TableMas.setModel(dtmMascotas);
    }
    
    public void llenaLista()
    {
        List<Mascotas> lst = MController.getlstMascotasController();
        dtmMascotas.setRowCount(0);
        for(int i=0; i<lst.size();i++)
        {
            Object[] vec=new Object[7];
            vec[0] = lst.get(i).getCodigo();
            vec[1] = lst.get(i).getNombre();
            vec[2] = lst.get(i).getRaza();
            vec[3] = lst.get(i).getEdad();
            vec[4] = lst.get(i).getPeso();
            vec[5] = lst.get(i).getTamaño();
            vec[6] = lst.get(i).getDueño();
            dtmMascotas.addRow(vec);                 
        }
        this.TableMas.setModel(dtmMascotas);    
    }
    
    public void transparenciaButton(){
        nuevo.setOpaque(false);
        nuevo.setContentAreaFilled(false);
        nuevo.setBorderPainted(false);
        
        guardar.setOpaque(false);
        guardar.setContentAreaFilled(false);
        guardar.setBorderPainted(false);
        
        eliminar.setOpaque(false);
        eliminar.setContentAreaFilled(false);
        eliminar.setBorderPainted(false);
        
        editar.setOpaque(false);
        editar.setContentAreaFilled(false);
        editar.setBorderPainted(false);
        
        regresar.setOpaque(false);
        regresar.setContentAreaFilled(false);
        regresar.setBorderPainted(false);
        
        buscar.setOpaque(false);
        buscar.setContentAreaFilled(false);
        buscar.setBorderPainted(false);
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        direccion_d = new javax.swing.JTextField();
        label_na3 = new javax.swing.JLabel();
        nombre_d = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        label_na = new javax.swing.JLabel();
        Id = new javax.swing.JTextField();
        telefono_d = new javax.swing.JTextField();
        labels = new javax.swing.JLabel();
        label_na1 = new javax.swing.JLabel();
        dni = new javax.swing.JTextField();
        label_na2 = new javax.swing.JLabel();
        correo = new javax.swing.JTextField();
        link = new javax.swing.JLabel();
        nuevo = new javax.swing.JButton();
        guardar = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableMas = new javax.swing.JTable();
        regresar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        tamaño = new javax.swing.JTextField();
        Id5 = new javax.swing.JTextField();
        peso = new javax.swing.JTextField();
        Combodue = new javax.swing.JComboBox<>();
        raza = new javax.swing.JTextField();
        edad = new javax.swing.JTextField();
        nom = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        Icon = new javax.swing.JLabel();
        buscar = new javax.swing.JButton();

        direccion_d.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        direccion_d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                direccion_dActionPerformed(evt);
            }
        });

        label_na3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        label_na3.setForeground(new java.awt.Color(102, 0, 102));
        label_na3.setText("Correo");

        nombre_d.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        nombre_d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombre_dActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 0, 102));
        jLabel1.setText("ID");

        label_na.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        label_na.setForeground(new java.awt.Color(102, 0, 102));
        label_na.setText("Nombre");

        telefono_d.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        telefono_d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telefono_dActionPerformed(evt);
            }
        });

        labels.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        labels.setForeground(new java.awt.Color(102, 0, 102));
        labels.setText("DNI");

        label_na1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        label_na1.setForeground(new java.awt.Color(102, 0, 102));
        label_na1.setText("Teléfono");

        label_na2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        label_na2.setForeground(new java.awt.Color(102, 0, 102));
        label_na2.setText("Dirección");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        link.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        link.setForeground(new java.awt.Color(153, 0, 153));
        link.setText("MASCOTAS");
        link.setToolTipText("");

        nuevo.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        nuevo.setForeground(new java.awt.Color(0, 102, 102));
        nuevo.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\nuevo3.png")); // NOI18N
        nuevo.setText("Nuevo");
        nuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        nuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nuevoActionPerformed(evt);
            }
        });

        guardar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        guardar.setForeground(new java.awt.Color(0, 102, 102));
        guardar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\guardar2.png")); // NOI18N
        guardar.setText("Guardar");
        guardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        guardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });

        editar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        editar.setForeground(new java.awt.Color(0, 102, 102));
        editar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\editar2.png")); // NOI18N
        editar.setText("Editar");
        editar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        editar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });

        eliminar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        eliminar.setForeground(new java.awt.Color(0, 102, 102));
        eliminar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\eliminar2.png")); // NOI18N
        eliminar.setText("Eliminar");
        eliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        eliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });

        TableMas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TableMas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableMasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TableMas);

        regresar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        regresar.setForeground(new java.awt.Color(0, 102, 102));
        regresar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\regresar3.png")); // NOI18N
        regresar.setText("Regresar");
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registro", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Cascadia Mono", 0, 14), new java.awt.Color(0, 102, 102))); // NOI18N

        peso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesoActionPerformed(evt);
            }
        });

        Combodue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CombodueActionPerformed(evt);
            }
        });

        edad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edadActionPerformed(evt);
            }
        });

        nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 102));
        jLabel6.setText("Raza  :");

        jLabel7.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 0, 102));
        jLabel7.setText("Peso  :");

        jLabel8.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 0, 102));
        jLabel8.setText("Dueño :");

        jLabel9.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 0, 102));
        jLabel9.setText("Id    :");

        jLabel10.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 0, 102));
        jLabel10.setText("Nombre :");

        jLabel11.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(204, 0, 102));
        jLabel11.setText("Edad   :");

        jLabel12.setFont(new java.awt.Font("Cascadia Mono", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(204, 0, 102));
        jLabel12.setText("Tamaño:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Combodue, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(Id5, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(raza, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE)
                        .addComponent(peso)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tamaño)
                    .addComponent(edad, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE)
                    .addComponent(nom, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE))
                .addGap(15, 15, 15))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(Combodue, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Id5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nom, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(edad, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(raza, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6)
                                .addComponent(jLabel11)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(peso)
                                    .addGap(1, 1, 1))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(tamaño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel12)))
                            .addComponent(jLabel7))
                        .addGap(45, 45, 45)))
                .addGap(16, 16, 16))
        );

        Icon.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\iguana2.png")); // NOI18N

        buscar.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        buscar.setForeground(new java.awt.Color(0, 102, 102));
        buscar.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\Dropbox\\Mi PC (LAPTOP-9BO1EO5S)\\Downloads\\icons\\mascotas2.png")); // NOI18N
        buscar.setText("Buscar");
        buscar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        buscar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(regresar)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 742, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(nuevo)
                                .addGap(51, 51, 51)
                                .addComponent(guardar)
                                .addGap(65, 65, 65)
                                .addComponent(editar)
                                .addGap(62, 62, 62)
                                .addComponent(eliminar)
                                .addGap(45, 45, 45)
                                .addComponent(buscar))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Icon)
                        .addGap(240, 240, 240)
                        .addComponent(link)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(link)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nuevo)
                            .addComponent(guardar, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(editar, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(eliminar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(regresar))
                    .addComponent(buscar))
                .addGap(17, 17, 17))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void direccion_dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_direccion_dActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_direccion_dActionPerformed

    private void nombre_dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombre_dActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombre_dActionPerformed

    private void telefono_dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telefono_dActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telefono_dActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        // TODO add your handling code here:
            // Verificar si todos los campos están llenos
        if (Id5.getText().isEmpty() || nom.getText().isEmpty() || raza.getText().isEmpty() ||
            edad.getText().isEmpty() || peso.getText().isEmpty() || tamaño.getText().isEmpty() ||
            Combodue.getSelectedItem() == null) {
            // Mostrar mensaje de error indicando los campos faltantes
            String mensaje = "Falta completar los siguientes campos:\n";
            if (Id5.getText().isEmpty()) {
                mensaje += "* Código\n";
            }
            if (nom.getText().isEmpty()) {
                mensaje += "* Nombre\n";
            }
            if (raza.getText().isEmpty()) {
                mensaje += "* Raza\n";
            }
            if (edad.getText().isEmpty()) {
                mensaje += "* Edad\n";
            }
            if (peso.getText().isEmpty()) {
                mensaje += "* Peso\n";
            }
            if (tamaño.getText().isEmpty()) {
                mensaje += "* Tamaño\n";
            }
            if (Combodue.getSelectedItem() == null) {
                mensaje += "* Dueño\n";
            }
            JOptionPane.showMessageDialog(this, mensaje, "No se puede completar la acción", JOptionPane.ERROR_MESSAGE);
        } else {
            Mascotas objMas = new Mascotas();
            objMas.setCodigo(Id5.getText());
            objMas.setNombre(nom.getText());
            objMas.setRaza(raza.getText());
            objMas.setEdad(edad.getText());
            objMas.setPeso(peso.getText());
            objMas.setTamaño(tamaño.getText());
            objMas.setDueño(Combodue.getSelectedItem().toString()); 
            MController.addMascotasController(objMas);
            JOptionPane.showMessageDialog(this, "Mascota registrada satisfactoriamente!!");
            llenaLista();
        }

    }//GEN-LAST:event_guardarActionPerformed

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        FrmPrincipal pc = new FrmPrincipal();
        pc.setVisible(true);
    }//GEN-LAST:event_regresarActionPerformed

    private void pesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pesoActionPerformed

    private void edadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_edadActionPerformed

    private void nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomActionPerformed

    private void CombodueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CombodueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CombodueActionPerformed

    private void TableMasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableMasMouseClicked
        // TODO add your handling code here:
        this.Id5.setText(this.dtmMascotas.getValueAt(this.TableMas.getSelectedRow(),0).toString());
        this.nom.setText(this.dtmMascotas.getValueAt(this.TableMas.getSelectedRow(),1).toString());
        this.raza.setText(this.dtmMascotas.getValueAt(this.TableMas.getSelectedRow(),2).toString());
        this.edad.setText(this.dtmMascotas.getValueAt(this.TableMas.getSelectedRow(),3).toString());
        this.peso.setText(this.dtmMascotas.getValueAt(this.TableMas.getSelectedRow(),4).toString());
        this.tamaño.setText(this.dtmMascotas.getValueAt(this.TableMas.getSelectedRow(),5).toString());
        this.Combodue.setSelectedItem(this.dtmMascotas.getValueAt(this.TableMas.getSelectedRow(),6).toString());
        
    }//GEN-LAST:event_TableMasMouseClicked

    private void nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nuevoActionPerformed
        // TODO add your handling code here:
        Id5.setText(""); // Limpia el contenido del textField
        nom.setText(""); 
        raza.setText("");
        edad.setText("");
        peso.setText("");
        tamaño.setText("");
        Combodue.setSelectedItem("");
    }//GEN-LAST:event_nuevoActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        // TODO add your handling code here:
        int option = JOptionPane.showConfirmDialog(this, "¿Deseas realizar esta acción?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
        Mascotas objMas = new Mascotas();/*CREA EL OBJETO*/
        objMas.setCodigo(this.Id5.getText());/*PASAR PARAMETRO DEL CODIGO*/
        MController.removeMController(objMas);/*LLAMR AL METODO*/
        
        llenaLista();/*LISTA ACTUALIZADA*/
           JOptionPane.showMessageDialog(this, "Mascota eliminada satisfactoriamente!!'");
            } else if (option == JOptionPane.NO_OPTION) {
           JOptionPane.showMessageDialog(this, "Acción Cancelada");
            }
    }//GEN-LAST:event_eliminarActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
        // TODO add your handling code here:
        Mascotas objMas = new Mascotas();/*CREA EL OBJETO*/
            objMas.setCodigo(this.Id5.getText());
            objMas.setNombre(this.nom.getText());
            objMas.setRaza(this.raza.getText());
            objMas.setEdad(this.edad.getText());
            objMas.setPeso(this.peso.getText());
            objMas.setTamaño(this.tamaño.getText());
            objMas.setDueño((String) this.Combodue.getSelectedItem());
            MController.updateMController(objMas);
            JOptionPane.showMessageDialog(this, "Mascota actualizado satisfactoriamente!!");
            llenaLista();
    }//GEN-LAST:event_editarActionPerformed

    private void buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarActionPerformed
         buscarMascota();
    }
        void buscarMascota(){
            
            String cod=  nom.getText();
            if (nom.getText().equals("")){
                JOptionPane.showMessageDialog(this,"Ingresar Nombre de la Mascota");
            }else{
                mascotas = mdao.listarID(cod);
                if (mascotas.getNombre()!=null){
                    Id5.setText(""+mascotas.getCodigo());
                    raza.setText(""+mascotas.getRaza());
                    edad.setText(""+mascotas.getEdad());
                    peso.setText(""+mascotas.getPeso());
                    tamaño.setText(""+mascotas.getTamaño());
                    Combodue.setSelectedItem(""+mascotas.getDueño());
                }else{
                    JOptionPane.showConfirmDialog(this,"Mascota no registrado");
                    
                }
            }
    }//GEN-LAST:event_buscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmMascotas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Combodue;
    private javax.swing.JLabel Icon;
    public javax.swing.JTextField Id;
    private javax.swing.JTextField Id5;
    private javax.swing.JTable TableMas;
    private javax.swing.JButton buscar;
    public javax.swing.JTextField correo;
    public javax.swing.JTextField direccion_d;
    public javax.swing.JTextField dni;
    private javax.swing.JTextField edad;
    private javax.swing.JButton editar;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton guardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_na;
    private javax.swing.JLabel label_na1;
    private javax.swing.JLabel label_na2;
    private javax.swing.JLabel label_na3;
    private javax.swing.JLabel labels;
    private javax.swing.JLabel link;
    private javax.swing.JTextField nom;
    public javax.swing.JTextField nombre_d;
    private javax.swing.JButton nuevo;
    private javax.swing.JTextField peso;
    private javax.swing.JTextField raza;
    private javax.swing.JButton regresar;
    private javax.swing.JTextField tamaño;
    public javax.swing.JTextField telefono_d;
    // End of variables declaration//GEN-END:variables

    
    }

