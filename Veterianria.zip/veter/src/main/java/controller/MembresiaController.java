/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Codigo;
import model.Dueños;
import model.IdMem;
import model.Membresia;
import model.Tipo;
import service.MembresiaRepository;

/**
 *.
 * @author USUARIO
 */
public class MembresiaController {
    public List<Tipo>getAllTipoController()
    {
       return new MembresiaRepository().getAllTipo();
    }
     public List<Dueños>getAllDueñosController()
    {
       return new MembresiaRepository().getAllDueños();
    }
    public void addMembresiaController(Membresia Men)
    {
        new MembresiaRepository().addMembresia(Men);
    }
    public List<Membresia> getlstMembreciaController()
    {
        return new MembresiaRepository().getAllMembresia();
    }
    public List<IdMem> getAllCodigoController()
    {
        return new MembresiaRepository().getAllCodigo();
    }
    public void removeMembresiaController(Membresia Men)
    {
         new MembresiaRepository().removeMembresia(Men);
    }
    public void updateMembresiaController(Membresia Men)
    {
         new MembresiaRepository().updateMembresia(Men);
    }
    public List<Membresia>searchById(String codigo)
    {
        return new MembresiaRepository().searchById(codigo);
    }
}
