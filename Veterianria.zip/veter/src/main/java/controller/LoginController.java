/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import service.LoginRepository;

/**
 *
 * @author USUARIO
 */
public class LoginController {
    private LoginRepository LoginRepository;

    public LoginController() {
        this.LoginRepository = new LoginRepository();
    }

    public boolean validarCredenciales(String usuario_admin, String contraseña) {
        return LoginRepository.validarUsuario(usuario_admin, contraseña);
    }
}
