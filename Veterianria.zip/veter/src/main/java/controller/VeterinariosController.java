/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Veterinarios;
import java.util.List;
import service.VeterinarioRepository;


public class VeterinariosController {
    public List<Veterinarios> getAllVeterinariosController()
    {
        return new VeterinarioRepository().getAllVeterinarios();
    }
    public void addVController(Veterinarios Vet)
    {
         new VeterinarioRepository().addVeterinarios(Vet);
    }
    public void removeVController(Veterinarios Vet)
    {
         new VeterinarioRepository().removeVeterinarios(Vet);
    }
    public void updateVController(Veterinarios Vet)
    {
         new VeterinarioRepository().updateVeterinarios(Vet);
    }
    public List<Veterinarios>searchById(String codigo)
    {
        return new VeterinarioRepository().searchById(codigo);
    }
    
}
