/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import model.Citas;
import model.Codigo;
import model.Dueños;
import model.Fecha;
import model.Hora;
import model.Mascotas;
import model.Veterinarios;
import service.CitaRepository;
import service.DueñosRepository;



/**
 *
 * @author USUARIO
 */
public class CitasController {
    public List<Mascotas>getAllNombesController()
    {
       return new CitaRepository().getAllNombres();
    }
    public List<Veterinarios>getAllVeterinariosController()
    {
       return new CitaRepository().getAllVeterinarios();
    }
    public List<Fecha>getAllFechaController()
    {
       return new CitaRepository().getAllFecha();
    }
    public List<Hora>getAllHoraController()
    {
       return new CitaRepository().getAllHora();
    }

    public List<Citas>getlstCitasController()
    {
        return new CitaRepository().getAllCitas();
    }
    public void addCController(Citas Cit)
    {
         new CitaRepository().addCitas(Cit);
    }
    public void removeCController(Citas Cit)
    {
         new CitaRepository().removeCitas(Cit);
    }
    public void updateCController(Citas Cit)
    {
         new CitaRepository().updateCitas(Cit);
    }
    public List<Citas>searchById(String codigo)
    {
        return new CitaRepository().searchById(codigo);
    }

   public List<Codigo>getlstCodigoController()
   {
       return new CitaRepository().getAllCodigo();
   }
}
